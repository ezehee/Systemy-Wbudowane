// PIC24FJ128GA010 Configuration Bit Settings

// 'C' source line config statements

// CONFIG2
#pragma config POSCMOD = XT             // Primary Oscillator Select (XT Oscillator mode selected)
#pragma config OSCIOFNC = ON            // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as port I/O (RC15))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = PRI              // Oscillator Select (Primary Oscillator (XT, HS, EC))
#pragma config IESO = ON                // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = ON              // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = ON              // Watchdog Timer Enable (Watchdog Timer is enabled)
#pragma config ICS = PGx2               // Comm Channel Select (Emulator/debugger uses EMUC2/EMUD2)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG port is disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include "lcd.h"
#include "buttons.h"
#include "adc.h"
#include "libpic30.h"
#include <stdio.h>

void system_init(void){
    LCD_Initialize();
    
    BUTTON_Enable(BUTTON_S3);
    BUTTON_Enable(BUTTON_S5);
}

void init(void) {
    ADC_SetConfiguration(ADC_CONFIGURATION_DEFAULT);
    ADC_ChannelEnable(ADC_CHANNEL_POTENTIOMETER);

    TRISA = 0x0000;
    TRISB |= (1 << 4);
}

void msCzas(int czas1, int czas2) {
    int m1 = czas1 / 60;
    int m2 = czas2 / 60;
    int s1 = czas1 % 60;
    int s2 = czas2 % 60;
    
    LCD_ClearScreen();
    
        //Gracz 1
    LCD_PutString("P1: ", 4);
    LCD_PutChar("0" + m1);
    LCD_PutChar(":");
    LCD_PutChar("0" + s1 / 10);
    LCD_PutChar("0" + s1 % 10);
    
    LCD_PutChar("\n");
    
        //Gracz 2
    LCD_PutString("P2: ", 4);
    LCD_PutChar("0" + m2);
    LCD_PutChar(":");
    LCD_PutChar("0" + s2 / 10);
    LCD_PutChar("0" + s2 % 10);
} 

int main(void) {
    system_init();
    init();
    
    unsigned char czas = 0;
    unsigned long adc_value = ADC_Read10bit(ADC_CHANNEL_POTENTIOMETER);
    if (adc_value > 680){
        czas = 300;
    } else if (adc_value > 340){
        czas = 180;
    }else {
        czas = 60;
    }

    int gracz1_czas = czas;
    int gracz2_czas = czas;
    int gracz = 0;

    msCzas(gracz1_czas, gracz2_czas);

    __delay32(3000000);

    while (1) {
        if (BUTTON_IsPressed(BUTTON_S3)) {
            if (gracz != 1) {
                gracz = 2;
                __delay32(300000);
                while (BUTTON_IsPressed(BUTTON_S3));
            }
        }

        if (BUTTON_IsPressed(BUTTON_S5)) {
            if (gracz != 2) {
                gracz = 1;
                __delay32(300000);
                while (BUTTON_IsPressed(BUTTON_S5));
            }
        }

        if (gracz == 1 && gracz1_czas > 0) {
            __delay32(3000000);
            gracz1_czas--;
            msCzas(gracz1_czas, gracz2_czas);
            if (gracz1_czas == 0){
                LCD_ClearScreen();
                LCD_PutString("Gracz 2 wygrywa!", 17);
                while (1);
            }
        }

        if (gracz == 2 && gracz2_czas > 0) {
            __delay32(3000000);
            gracz2_czas--;
            msCzas(gracz1_czas, gracz2_czas);
            if (gracz2_czas == 0){
                LCD_ClearScreen();
                LCD_PutString("Gracz 1 wygrywa!", 17);
                while (1);
            }
        }
    }

    return 0;
}
